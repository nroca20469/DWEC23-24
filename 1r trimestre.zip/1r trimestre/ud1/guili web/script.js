console.log("Vengo de un fichero");

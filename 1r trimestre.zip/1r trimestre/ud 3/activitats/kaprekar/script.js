//Creacion de variables
const numero = prompt("Elige un numero de 4 cifras");
console.log(numero);
let arrayNumeros = new Array(4);
let intentos = 0;



if(numero > 1000 && numero < 10000){  //Assegurar  que el numero es de 4 cifras

    //Passar numero a un array
    let arrayNumerica =  [...numero];  
    arrayNumeros = arrayNumerica.map(Number);  //--> Passar a numeros
 //   console.log(arrayNumeros);

    let arrayOrdenado = ordenar(arrayNumeros);
   //console.log(arrayOrdenado);
    let arrayOrdenadoAlReves = desordenar(arrayOrdenado);
   /* console.log(arrayOrdenadoAlReves);
    console.log(arrayOrdenado);
*/
    
    let contadorRepetida = 0;  //Contar las veces que se repite
    let auxiliar = 0;
    for (let i = 0; i < arrayNumerica.length; i++){
        if(arrayNumerica[i] == auxiliar){
            contadorRepetida++; 
        } else {
            auxiliar = arrayNumerica[i];
        }  
    }
    //console.log(arrayOrdenado.length);
    //console.log(contadorRepetida);

    if(contadorRepetida > 1){  //Que hay mas de 2 numeros repetidos
        let error = document.getElementById('textoError');
        error.innerHTML = "Su numero no es de 4 cifras, recarga la pagina para volver a intentar";
    } else {

        while(intentos < 8){

            let arrayOrdenado = ordenar(arrayNumeros);
            //console.log(arrayOrdenado);
            let arrayOrdenadoAlReves = desordenar(arrayOrdenado);
            /* console.log(arrayOrdenadoAlReves);
                console.log(arrayOrdenado);
                */
            let numero = restarNumeros(arrayOrdenadoAlReves, arrayOrdenado);
            
            
            numero = "\"" + numero + "\"";  //Passamos a string para poderlo hacer despues iterable(sino no lo es)
            arrayNumeros =  [...numero];  
            /*Borrar la primera i la ultima posicion, ya que antes eran "" i ahora son NaN */
            arrayNumeros.pop();
            arrayNumeros.shift();
            let arrayDef = arrayNumeros.map(Number); 
            let numero2 = arrayDef.join("");
            numero2 = parseInt(numero2);
            console.log(numero2);
            if(numero1 == numero2) {
                let victoria = document.getElementById('textoVictoria');
                victoria.innerHTML = "Ya ha acabado y ha funcionado correctamente";
                intentos = 8;
            }

           

            //arrayNumeros = [...numero];
            intentos ++;
            console.log(intentos);
        }
       

            
        

    }

} else {
    let error = document.getElementById('textoError');
    error.innerHTML = "Su numero no es de 4 cifras, recarga la pagina para volver a intentar";
}

function restarNumeros(arrayOrdenadoAlReves, arrayOrdenado){  //Necessitamos que tanto el array ordenado como el desordenado se resten
    let numero1; //Array ordenadoAlReves
    let numero2; //Array ordenado

    //Passar a numeros
    numero1 = arrayOrdenadoAlReves.join("");
    console.log("Numero1: " + numero1);
    let numeroFinal1 = parseInt(numero1);

    numero2 = arrayOrdenado.join("");
    console.log("Numero2: " + numero2);
    let numeroFinal2 = parseInt(numero2);

    console.log(numeroFinal1 + typeof numeroFinal1);
    console.log(numeroFinal2 + typeof numeroFinal2);

    let restarNumeros = resta(numeroFinal1, numeroFinal2);
    console.log(restarNumeros);

    return restarNumeros;
    
    /*let restaNum = resta(numero1, numero2);
    console.log(restaNum);
    console.log(typeof restaNum);
    let restant = "\"" + restaNum + "\"";
    console.log(typeof restant);
    
    let arrayNumeros =  [...restant];  
    arrayNumeros = arrayNumeros.map(Number);  
    //let arrayDesor = new Array(4);

    console.log(arrayNumeros);
    /*Borrar la primera i la ultima posicion, ya que antes eran "" i ahora son NaN */
   /* arrayNumeros.pop();
    arrayNumeros.shift();
    console.log(    );
    
    let arrayDesor = [...arrayNumeros];
   
    let arrayNumbers = [...arrayDesor];
    let arrayOrd = arrayNumbers.sort();

    while (intentos < 8){
        intentos ++;
        console.log("Intentos: " + intentos);
        restarNumeros(arrayDesor, arrayOrd);
        if(comprobarNumerosIguales(numero1, numero2)){
            console.log("FIN");
            intentos = 8;
        }
        
    } */
}

function resta(a, b) { return a - b;};
/*
function comprobarNumerosIguales (a, b){
    //NS COMO AHORA
    if(a === b) {
        return true;
    } else {
        return false ;
    }
}*/

function ordenar(arrayNumeros){
    //Ordenar el array de numeros
    let arrayOrdenado = arrayNumeros.sort();

    return arrayOrdenado;
}

function desordenar(arrayOrdenado){
    let arrayAuxiliar = arrayOrdenado;
    let arrayOrdenadoAlReves;
    
    arrayOrdenadoAlReves = arrayOrdenado.slice().reverse();  //Slice para copiar i luego revertir(sin cambiar el array original)

    return arrayOrdenadoAlReves;
}

function numerosIguales(a,b) {
    if(a == b) {
        return true;
    } else {
        return false;
    }
}